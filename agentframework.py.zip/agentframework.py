import random

#build an agent class with the parameter label assigned as 'self'
class Agent:
#define function __init__ using the self varaible
    def __init__ (self, environment, agents):
        #give them an awareness of the environment in which they move around
        self.environment = environment
        #give them an initial store of 0
        self.store = 0
        #generate random starting locations for the agents
        self._x = (random.randint(0,300))
        self._y = (random.randint(0,300))
        #give them an awareness of the other agents
        self.agents = agents

        
#define a basic walking function for each agent so they move randomly around
# the environment, implementing torus boundaries so they never leave the set
# environment
    def walk(self):
        if self.store <= 50:
            if random.random() < 0.5:
                self._x = (self._x + 1) % 299
            else:
                self._x = (self._x - 1) % 299
            
            if random.random() < 0.5:
                self._y = (self._y + 1) % 299
            else:
                self._y = (self._y - 1) % 299


#define a running function so that the sheep move faster when they have more
# energy, also with torus boundaries
    def run(self):
        if self.store > 50:
            if random.random() < 0.5:
                self._x = (self._x + 3) % 299
            else:
                self._x = (self._x - 3) % 299
            
            if random.random() < 0.5:
                self._y = (self._y + 3) % 299
            else:
                self._y = (self._y - 3) % 299
           

#define an eating function so that the sheep can nibble the environment and is
# dependent on how much food is in that particular spot             
    def eat(self):
        if self.environment[self._y][self._x] > 10:
            self.environment[self._y][self._x] -= 10
            self.store += 10
        
        if 0>self.environment[self._y][self._x] < 10:
            self.store += self.environment[self._y][self._x]
            self.environment[self._y][self._x] -= self.environment[self._y][self._x]
        

#define function so that if the sheep eat too much they can be sick and return
# the store to the environment
    def vom(self):
        if self.store > 100:
            self.environment[self._y][self._x] = self.environment[self._y][self._x] + self.store        
            self.store = 0


#share function uses a knowledge of the neighbourhood and a distance calculation
# function so that if the sheep come clost to each other they can share their
# stores. If an agents store is particularly low it takes a greater share of 
# the total than the other agent
    def share_with_neighbours(self, neighbourhood):
        for agent in self.agents:
            distance = self.distance_between(agent)
            if distance <= neighbourhood:
                sum = self.store + agent.store
                if self.store < 10:
                    self.store = sum * 0.75
                    agent.store = sum * 0.25
                else:
                    self.store = sum/2
                    agent.store = sum/2


#define a function that calculates the distance betweeen agents to be used in
# the function above             
    def distance_between(self, agent):
        return (((self._x - agent._x)**2) + ((self._y - agent._y)**2))**0.5 