#import functions go at the top of a file so they are easy to find
import random 
import matplotlib.pyplot
import matplotlib.animation
import agentframeworkwolves
import csv


#create an empty list for the environment data to be read into
environment = []


#open and read in raster file to create the environment
file = open('in.txt', newline='')
reader = csv.reader(file, quoting=csv.QUOTE_NONNUMERIC)
#append the raster data to the environment list
for row in reader:
    rowlist = []
    for item in row:
        rowlist.append(item)
    environment.append(rowlist)
#close the file after it has been used
file.close()    



#set the initial numbers of agents, iterations, neighbourhood, and store
num_of_agents = 25
num_of_iterations = 100
neighbourhood = 10
store = 0
num_of_wolves = 5


#create empty lists for the agents data to be appended to
agents = []
wolves = []



#create the agents and assign the necessary information from the agent 
# framework into the agents list, automated for every agent
for i in range(num_of_agents):
    agents.append(agentframeworkwolves.Agent(environment, agents))

for i in range(num_of_wolves):
    wolves.append(agentframeworkwolves.Wolf(environment, wolves, agents, store))



#run the functions defined in the agent framework whilst randomising the order
# in which the agents are processed
random.shuffle(agents)    
for j in range(num_of_iterations):    
    for i in range(num_of_agents):   
        agents[i].walk()
        agents[i].run()
        agents[i].eat()
        agents[i].vom()
        agents[i].share_with_neighbours(neighbourhood)
      
random.shuffle(wolves)
for j in range(num_of_iterations):
    for i in range(num_of_wolves):
        wolves[i].move()
        wolves[i].eat_sheep(neighbourhood, agents, store)
        wolves[i].vom()


#plot the resultant environment map, defining the x and y limits and the colour, 
# style and size of the scatter markers for the different types of agents
matplotlib.pyplot.xlim(0, 300)
matplotlib.pyplot.ylim(0, 300)
matplotlib.pyplot.imshow(environment)
for agent in agents:
    matplotlib.pyplot.scatter(agent._x,agent._y, color='white', s=35)
for i in range(num_of_wolves):
    matplotlib.pyplot.scatter(wolves[i]._x,wolves[i]._y, color='brown', 
                              marker= "s", s=100)
    
print(num_of_agents)